# 🤖 Phone Agent

An Android app that controls your phone for you. Type or speak a task, like *"Open WhatsApp and tell Ali I'll be late"*, and it reads the screen, then taps, types and scrolls until the task is done. Google's Gemini (free tier) is its brain.

Before it sends, pays, deletes or posts anything, it shows a **"Allow this?"** card and waits for you. It never types passwords or OTPs. Tap the floating button at any time to stop it.

---

## How it works

```
 You: "Turn on dark mode"
        │
        ▼
 ┌─────────────┐   screen as text    ┌──────────┐
 │ Accessibility│ ─────────────────► │  Gemini  │
 │   Service    │ ◄───────────────── │   API    │
 └─────────────┘   "tap [7]"         └──────────┘
   taps / types / swipes
        │
        └── repeat until Gemini calls finish()
```

| File | What it does |
|---|---|
| `AgentAccessibilityService.kt` | Eyes and hands: reads every element on screen, taps, types, swipes, opens apps, takes screenshots |
| `Agent.kt` | The loop: screen → Gemini → action → new screen … plus the instructions (system prompt) Gemini follows |
| `Tools.kt` | The list of actions Gemini may use, and the code behind each one |
| `GeminiClient.kt` | Talks to the Gemini API, and waits and retries when the free-tier limit is hit |
| `OverlayPrompt.kt` | The "Allow this?" and question cards that appear over any app |
| `FloatingBubbleService.kt` | The floating button (tap = new task, tap while running = stop) |
| `MainActivity.kt` | Setup screen, task box, live log |
| `QuickTaskActivity.kt` | The small task box opened from the floating button |
| `Voice.kt` / `Speaker.kt` | Speech-to-text for tasks, text-to-speech for answers |

---

## Step 1 — Get a free Gemini API key

1. On your phone's browser, go to **aistudio.google.com** and sign in with your Google account.
2. Tap **Get API key → Create API key**. No card or billing needed.
3. Copy the key (it starts with `AIza`) and keep it private, for example in your notes app.

Each task step is one request. A simple task is usually 5–15 steps. The free tier allows only a limited number of requests per minute and per day, so on a long task you may see *"Free-tier limit reached, waiting…"*. That's normal; it continues by itself.

## Step 2 — Build the app (pick one)

### Option A: Android Studio (on your computer)

1. Install **Android Studio** from developer.android.com/studio.
2. Unzip this project. In Android Studio choose **File → Open** and pick the `phone-agent` folder.
3. Wait for "Gradle sync" to finish (first time takes several minutes; it downloads what it needs).
4. On your phone: **Settings → About phone → tap "Build number" 7 times** to unlock Developer options. Then **Settings → Developer options → turn on USB debugging**.
5. Connect the phone by USB, accept the "Allow USB debugging?" prompt, and press the green ▶ **Run** button in Android Studio.

### Option B: No computer setup — let GitHub build it

1. Create a free account at github.com and make a new **private** repository.
2. Upload all files from this folder (keep the folder structure, including `.github/workflows`).
3. Open the **Actions** tab. A "Build APK" run starts automatically; wait ~5 minutes for a green tick.
4. Click the run → download **PhoneAgent-apk** under Artifacts → unzip it → copy the `.apk` to your phone.
5. Open the APK on your phone and allow "Install unknown apps" when asked.

## Step 3 — Set it up on the phone

Open **Phone Agent** and follow the setup section top to bottom:

1. **Paste your Gemini key** and tap **Save key**. Leave the model as `gemini-3.8-flash`.
2. **Turn on screen control** → you land in Accessibility settings → find **Phone Agent** (sometimes under *Installed apps* / *Downloaded apps*) → switch it on → allow.
   - Android 13+ may say *"Restricted setting"*. Fix: **Settings → Apps → Phone Agent → ⋮ (top right) → Allow restricted settings**, then try again.
3. **Allow display over other apps** → switch it on for Phone Agent.
4. Turn on **Floating button** if you want the bubble over every app.

## Step 4 — Try it

Start with simple tasks:

- "Turn on dark mode"
- "Open YouTube and search for cricket highlights"
- "What's the battery percentage?"
- "Set an alarm for 6:30 am"
- "Open Chrome and find today's weather in Dubai"
- "Open WhatsApp and send Ali 'running 10 minutes late'" (you'll get an Allow card before it sends)

Use the **🎤 mic** to speak, or tap the **floating button** from inside any app.

---

## Tips & troubleshooting

| Problem | Fix |
|---|---|
| "Accessibility service is off" | Android sometimes turns it off after updates or battery saving. Switch it on again; also set **Settings → Apps → Phone Agent → Battery → Unrestricted**. |
| It taps the wrong thing | Some apps label buttons poorly. Gemini will fall back to a screenshot (`look_at_screen`). Being specific in your task helps. |
| Screenshot fails | Banking/password screens block screenshots on purpose. That's expected. |
| HTTP 400 "API key not valid" | Key is wrong — copy it again from AI Studio. |
| HTTP 404 / model not found | Google renamed the model. Check ai.google.dev/gemini-api/docs/models and type the new Flash model name in setup. |
| "Free-tier limit reached" for a long time | You've hit today's free limit. Try again tomorrow, or try `gemini-3.5-flash-lite` (faster, less clever). |
| It's slow | Each step is a round trip to Gemini (~2–5 s), plus pauses when the free limit is hit. |

## Ideas for next versions

- **Wake word** ("Hey Agent") so you don't need to tap anything.
- **Memory** of your contacts' nicknames and preferences.
- **Scheduled tasks** ("every morning at 8, read me my unread messages").
- **Shortcuts**: save a finished task as a one-tap button.

## Privacy

What's on your screen during a task is sent to Google's Gemini API to decide the next step. The app only reads the screen while a task is running. Don't run it on screens with information you don't want to send, and don't share your API key. Note: on Google's free tier, Google may use what you send to improve its products, so avoid running tasks on private screens (banking, health, private chats) if that matters to you.
