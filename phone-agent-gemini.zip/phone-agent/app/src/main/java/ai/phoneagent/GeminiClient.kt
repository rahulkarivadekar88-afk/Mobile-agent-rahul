package ai.phoneagent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Minimal client for the Google Gemini API (generateContent) with function calling.
 * Get a free key at aistudio.google.com → "Get API key".
 */
class GeminiClient(private val apiKey: String, private val model: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    /** Sends the conversation and returns the model's reply `content` ({role:"model", parts:[…]}). */
    suspend fun send(system: String, functions: JSONArray, contents: JSONArray, onWait: (String) -> Unit = {}): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", functions)))
            .put("toolConfig", JSONObject().put("functionCallingConfig", JSONObject().put("mode", "AUTO")))
            .toString()

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        var lastError = ""
        for (attempt in 0 until 5) {
            val (code, text) = withContext(Dispatchers.IO) {
                http.newCall(request).execute().use { it.code to (it.body?.string().orEmpty()) }
            }
            if (code in 200..299) {
                val json = JSONObject(text)
                val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
                    ?: throw RuntimeException("Gemini returned no answer" +
                        (json.optJSONObject("promptFeedback")?.optString("blockReason")?.let { " (blocked: $it)" } ?: ""))
                val content = candidate.optJSONObject("content")
                if (content == null || !content.has("parts")) {
                    throw RuntimeException("Gemini stopped: ${candidate.optString("finishReason", "no content")}")
                }
                if (!content.has("role")) content.put("role", "model")
                return content
            }
            lastError = "HTTP $code: " + runCatching {
                JSONObject(text).getJSONObject("error").getString("message")
            }.getOrDefault(text.take(300))

            // 429 = free-tier rate limit; 5xx = Google busy. Wait and retry; anything else is a real error.
            if (code != 429 && code < 500) throw RuntimeException(lastError)
            val waitSec = if (code == 429) 20L * (attempt + 1) else 3L * (attempt + 1)
            onWait("Free-tier limit reached, waiting ${waitSec}s…")
            delay(waitSec * 1000)
        }
        throw RuntimeException(lastError)
    }
}
