package ai.phoneagent

import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Speech-to-text using the phone's built-in voice typing (the Google mic pop-up).
 * Create it as a field in an Activity, then call listen { text -> … }.
 */
class Voice(private val activity: AppCompatActivity) {
    private var onText: ((String) -> Unit)? = null

    private val launcher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) onText?.invoke(text)
    }

    fun listen(onText: (String) -> Unit) {
        this.onText = onText
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "What should I do?")
        try { launcher.launch(intent) }
        catch (e: Exception) { Toast.makeText(activity, "Voice typing isn't available on this phone", Toast.LENGTH_LONG).show() }
    }
}
