package ai.phoneagent

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity

/** The small task box that pops up when you tap the floating button. */
class QuickTaskActivity : AppCompatActivity() {

    private val voice = Voice(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quick_task)

        val input = findViewById<EditText>(R.id.quickInput)
        fun go() {
            val task = input.text.toString().trim()
            if (task.isEmpty()) return
            if (AgentAccessibilityService.instance == null || Settings(this).apiKey.isBlank()) {
                android.widget.Toast.makeText(this, "Finish setup in the Phone Agent app first", android.widget.Toast.LENGTH_LONG).show()
                return
            }
            Agent.start(this, task)
            finish() // close so the agent can see and use the app underneath
        }

        findViewById<Button>(R.id.quickGo).setOnClickListener { go() }
        findViewById<ImageButton>(R.id.quickMic).setOnClickListener {
            voice.listen { text -> input.setText(text); go() }
        }
        input.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_GO) { go(); true } else false }
    }
}
