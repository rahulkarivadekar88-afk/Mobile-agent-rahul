package ai.phoneagent

import android.content.Context

/** Small wrapper around the app's saved settings. */
class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("agent", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()

    /** Gemini model to use. Flash models are on the free tier. */
    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    /** Read the final answer out loud. */
    var speakResults: Boolean
        get() = prefs.getBoolean("speak", true)
        set(v) = prefs.edit().putBoolean("speak", v).apply()

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
    }
}
