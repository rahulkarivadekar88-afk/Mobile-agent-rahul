package ai.phoneagent

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var settings: Settings
    private val voice = Voice(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        settings = Settings(this)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // --- setup
        val apiKey = findViewById<EditText>(R.id.apiKey).apply { setText(settings.apiKey) }
        val model = findViewById<EditText>(R.id.model).apply { setText(settings.model) }
        findViewById<Button>(R.id.saveKey).setOnClickListener {
            settings.apiKey = apiKey.text.toString()
            settings.model = model.text.toString()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            Toast.makeText(this, "Find \"Phone Agent\" (maybe under Installed apps) and switch it on", Toast.LENGTH_LONG).show()
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<MaterialSwitch>(R.id.switchBubble).setOnCheckedChangeListener { sw, on ->
            if (on && !AndroidSettings.canDrawOverlays(this)) {
                sw.isChecked = false
                Toast.makeText(this, "Allow \"display over other apps\" first", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            val intent = Intent(this, FloatingBubbleService::class.java)
            if (on) startForegroundService(intent) else stopService(intent)
        }
        findViewById<MaterialSwitch>(R.id.switchSpeak).apply {
            isChecked = settings.speakResults
            setOnCheckedChangeListener { _, on -> settings.speakResults = on }
        }

        // --- task
        val task = findViewById<EditText>(R.id.taskInput)
        fun run() {
            val text = task.text.toString().trim()
            if (text.isEmpty()) return
            if (!ready()) return
            Agent.start(this, text)
            task.setText("")
            moveTaskToBack(true) // step aside so the agent works on the phone, not on this screen
        }
        findViewById<Button>(R.id.btnRun).setOnClickListener { run() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { Agent.stop() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { voice.listen { task.setText(it); run() } }
        task.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_GO) { run(); true } else false }

        // --- live log
        val status = findViewById<TextView>(R.id.status)
        val log = findViewById<TextView>(R.id.log)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Agent.state.collect { s ->
                    status.text = "Status: ${s.status}"
                    log.text = s.log.joinToString("\n")
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val acc = isAccessibilityOn()
        findViewById<Button>(R.id.btnAccessibility).text =
            if (acc) "✅ Screen control is ON" else "1. Turn on screen control (Accessibility)"
        findViewById<Button>(R.id.btnOverlay).text =
            if (AndroidSettings.canDrawOverlays(this)) "✅ Can show over other apps" else "2. Allow display over other apps"
    }

    private fun ready(): Boolean {
        val problem = when {
            settings.apiKey.isBlank() -> "Add and save your Gemini API key first"
            !isAccessibilityOn() -> "Turn on screen control (Accessibility) first"
            !AndroidSettings.canDrawOverlays(this) -> "Allow display over other apps first (needed to ask you before risky steps)"
            else -> null
        }
        problem?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        return problem == null
    }

    private fun isAccessibilityOn(): Boolean {
        if (AgentAccessibilityService.instance != null) return true
        val enabled = AndroidSettings.Secure.getString(contentResolver, AndroidSettings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, AgentAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }
}
