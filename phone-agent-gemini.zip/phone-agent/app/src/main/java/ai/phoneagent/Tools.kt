package ai.phoneagent

import android.content.Context
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** The actions Gemini is allowed to take, and the code that carries each one out. */
object Tools {

    data class Result(val text: String, val imageBase64: String? = null)

    val definitions: JSONArray by lazy {
        JSONArray()
            .put(tool("tap", "Tap an on-screen element by its number.",
                props("element" to int("Element number from the latest screen list")), "element"))
            .put(tool("tap_at", "Tap at pixel coordinates. Use only with coordinates read from a look_at_screen screenshot.",
                props("x" to int("x in the screenshot"), "y" to int("y in the screenshot")), "x", "y"))
            .put(tool("long_press", "Long-press an element by its number.",
                props("element" to int("Element number")), "element"))
            .put(tool("type_text", "Replace the text in a text box. Taps the box first.",
                props("element" to int("Element number of the text box"),
                    "text" to str("Text to enter"),
                    "press_enter" to JSONObject().put("type", "boolean").put("description", "Press Enter/Search after typing")),
                "element", "text"))
            .put(tool("press_enter", "Press Enter/Search/Send on the keyboard for the focused text box.", props()))
            .put(tool("scroll", "Scroll the screen (or one scrollable element) to reveal more.",
                props("direction" to JSONObject().put("type", "string").put("enum", JSONArray(listOf("up", "down", "left", "right"))),
                    "element" to int("Optional: number of the scrollable element")), "direction"))
            .put(tool("press_button", "Press a system button.",
                props("button" to JSONObject().put("type", "string")
                    .put("enum", JSONArray(listOf("back", "home", "recents", "notifications", "quick_settings")))), "button"))
            .put(tool("open_app", "Open an installed app by name, e.g. \"WhatsApp\", \"Settings\", \"Chrome\".",
                props("name" to str("App name")), "name"))
            .put(tool("wait", "Wait for something to load.",
                props("seconds" to int("1-10")), "seconds"))
            .put(tool("look_at_screen", "Take a screenshot to see the screen visually. Coordinates in it can be used with tap_at.", props()))
            .put(tool("ask_user", "Ask the user a question and get their typed answer.",
                props("question" to str("The question")), "question"))
            .put(tool("confirm_with_user", "Required before sending, posting, paying, buying, deleting, calling or changing settings. Returns YES or NO.",
                props("action" to str("Exactly what you are about to do")), "action"))
            .put(tool("finish", "End the task.",
                props("summary" to str("Short summary for the user, including any answer they asked for")), "summary"))
    }

    suspend fun execute(ctx: Context, svc: AgentAccessibilityService, name: String, input: JSONObject): Result = when (name) {
        "tap" -> Result(svc.tap(input.getInt("element")))
        "tap_at" -> {
            val s = svc.lastScreenshotScale
            val ok = svc.tapAt((input.getInt("x") / s).toInt(), (input.getInt("y") / s).toInt())
            Result(if (ok) "Tapped" else "Tap failed")
        }
        "long_press" -> Result(svc.longPress(input.getInt("element")))
        "type_text" -> {
            var r = svc.typeText(input.getInt("element"), input.getString("text"))
            if (input.optBoolean("press_enter")) { delay(300); r += "; " + svc.pressEnter() }
            Result(r)
        }
        "press_enter" -> Result(svc.pressEnter())
        "scroll" -> Result(svc.scroll(input.getString("direction"), if (input.has("element")) input.getInt("element") else null))
        "press_button" -> Result(svc.globalAction(input.getString("button")))
        "open_app" -> { val r = svc.openApp(input.getString("name")); delay(1500); Result(r) }
        "wait" -> { delay(input.optInt("seconds", 2).coerceIn(1, 10) * 1000L); Result("Waited") }
        "look_at_screen" -> {
            val img = svc.screenshotBase64()
            if (img == null) Result("Screenshot not available on this screen (some apps block it).")
            else Result("Screenshot attached (1024px on the long side).", img)
        }
        "ask_user" -> {
            val answer = OverlayPrompt.ask(ctx, input.getString("question"), withTextField = true)
            Result(answer?.let { "User answered: $it" } ?: "User did not answer. Stop and finish.")
        }
        "confirm_with_user" -> {
            val answer = OverlayPrompt.ask(ctx, "Allow this?\n\n" + input.getString("action"), withTextField = false)
            Result(if (answer == "YES") "YES — go ahead." else "NO — the user did not allow it. Do not do it.")
        }
        else -> Result("Unknown tool $name")
    }

    // --- tiny helpers that build Gemini "function declarations"
    private fun tool(name: String, description: String, properties: JSONObject, vararg required: String): JSONObject {
        val fn = JSONObject().put("name", name).put("description", description)
        // Gemini rejects an empty parameter object, so tools without inputs get no "parameters" at all.
        if (properties.length() > 0) fn.put("parameters", JSONObject()
            .put("type", "object").put("properties", properties).put("required", JSONArray(required.toList())))
        return fn
    }

    private fun props(vararg p: Pair<String, JSONObject>) = JSONObject().apply { p.forEach { put(it.first, it.second) } }
    private fun int(d: String) = JSONObject().put("type", "integer").put("description", d)
    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
}
