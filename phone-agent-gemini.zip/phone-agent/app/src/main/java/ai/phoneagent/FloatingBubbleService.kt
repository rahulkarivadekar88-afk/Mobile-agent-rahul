package ai.phoneagent

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * A draggable round button that floats over every app.
 *  • Tap it when idle  → opens a small box to type or speak a task.
 *  • Tap it while busy → stops the agent.
 * A label next to it shows what the agent is doing.
 */
class FloatingBubbleService : Service() {

    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        val dp = resources.displayMetrics.density
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.ic_agent)
            layoutParams = LinearLayout.LayoutParams((56 * dp).toInt(), (56 * dp).toInt())
            elevation = 8 * dp
            contentDescription = "Phone Agent"
        }
        val label = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 13f
            setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt())
            background = GradientDrawable().apply { setColor(0xE61F1E1D.toInt()); cornerRadius = 14 * dp }
            maxWidth = (220 * dp).toInt()
            visibility = android.view.View.GONE
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(bubble); addView(label)
        }
        root = layout

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = (300 * dp).toInt() }

        // Drag to move, tap to act.
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX; val dy = e.rawY - touchY
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    params.x = startX + dx.toInt(); params.y = startY + dy.toInt()
                    wm.updateViewLayout(layout, params); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onBubbleTapped(); true }
                else -> false
            }
        }
        wm.addView(layout, params)

        scope.launch {
            Agent.state.collect { s ->
                label.visibility = if (s.running) android.view.View.VISIBLE else android.view.View.GONE
                label.text = if (s.running) "${s.status}\n(tap to stop)" else ""
                bubble.alpha = if (s.running) 1f else 0.85f
                runCatching { wm.updateViewLayout(layout, params) }
            }
        }
    }

    private fun onBubbleTapped() {
        if (Agent.isRunning()) Agent.stop()
        else startActivity(Intent(this, QuickTaskActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun startForegroundWithNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_MIN))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, FloatingBubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_agent)
            .setContentTitle("Phone Agent button is on")
            .setContentText("Tap the floating button to give a task")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Hide button", stop).build())
            .build()
        if (android.os.Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        scope.cancel()
        root?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "bubble"
        const val ACTION_STOP = "stop"
    }
}
