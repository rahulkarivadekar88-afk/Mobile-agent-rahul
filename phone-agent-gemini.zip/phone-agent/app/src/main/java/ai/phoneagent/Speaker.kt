package ai.phoneagent

import android.content.Context
import android.speech.tts.TextToSpeech

/** Reads the agent's final answer out loud. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun say(ctx: Context, text: String) {
        val engine = tts
        if (engine != null && ready) {
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent")
            return
        }
        pending = text
        if (engine == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                ready = status == TextToSpeech.SUCCESS
                if (ready) pending?.let { tts?.speak(it, TextToSpeech.QUEUE_FLUSH, null, "agent") }
                pending = null
            }
        }
    }
}
