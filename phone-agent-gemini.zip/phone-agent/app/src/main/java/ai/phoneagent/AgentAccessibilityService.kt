package ai.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * The agent's "eyes and hands".
 *
 * Android gives accessibility services (the same system screen readers use) permission to
 * read every element on screen and to tap, type and swipe. The agent loop asks this service
 * for a text description of the screen, sends it to Gemini, and then calls the action methods
 * below with whatever Gemini decides to do.
 */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        /** The running service, or null if the user hasn't switched it on in Settings. */
        @Volatile var instance: AgentAccessibilityService? = null
            private set
    }

    /** Elements from the most recent screen read, so Gemini can refer to them by number. */
    private var lastElements: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* we read on demand */ }
    override fun onInterrupt() {}

    // ------------------------------------------------------------------ reading the screen

    /**
     * Returns a compact, numbered text list of what is on screen, e.g.
     *   App: com.whatsapp
     *   [0] EditText "Search" (editable) @540,180
     *   [1] TextView "Ali Khan" (clickable) @540,420
     */
    fun describeScreen(): String {
        val elements = mutableListOf<AccessibilityNodeInfo>()
        val lines = mutableListOf<String>()
        var foregroundPackage = "unknown"

        val roots = windows
            .sortedByDescending { it.layer }
            .mapNotNull { it.root }
            .filter { it.packageName?.toString() != packageName } // hide our own bubble/overlays
            .ifEmpty { listOfNotNull(rootInActiveWindow) }

        roots.firstOrNull()?.packageName?.let { foregroundPackage = it.toString() }

        for (root in roots) walk(root, elements, lines, depth = 0)

        lastElements = elements
        val maxLines = 220
        val shown = if (lines.size > maxLines) lines.take(maxLines) + "… (${lines.size - maxLines} more elements cut; scroll to see more)" else lines
        val keyboard = if (windows.any { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD }) "\nKeyboard: open" else ""
        return "App: $foregroundPackage$keyboard\nScreen elements:\n" +
            (if (shown.isEmpty()) "(nothing readable — try look_at_screen)" else shown.joinToString("\n"))
    }

    private fun walk(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, lines: MutableList<String>, depth: Int) {
        if (depth > 40 || !node.isVisibleToUser) return

        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val hint = node.hintText?.toString()?.trim().orEmpty()
        val interesting = node.isClickable || node.isLongClickable || node.isEditable ||
            node.isScrollable || node.isCheckable || text.isNotEmpty() || desc.isNotEmpty()

        if (interesting) {
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (r.width() > 0 && r.height() > 0) {
                val id = out.size
                out.add(node)
                val cls = node.className?.toString()?.substringAfterLast('.') ?: "View"
                val label = listOf(text, desc, if (node.isEditable && text.isEmpty()) hint else "")
                    .filter { it.isNotEmpty() }.distinct().joinToString(" | ").take(120)
                val flags = buildList {
                    if (node.isClickable) add("clickable")
                    if (node.isLongClickable) add("long-clickable")
                    if (node.isEditable) add("editable")
                    if (node.isScrollable) add("scrollable")
                    if (node.isCheckable) add(if (node.isChecked) "checked" else "unchecked")
                    if (node.isFocused) add("focused")
                    if (!node.isEnabled) add("disabled")
                }.joinToString(",")
                lines.add("[$id] $cls \"${label.replace("\n", " ")}\" ($flags) @${r.centerX()},${r.centerY()}")
            }
        }
        for (i in 0 until node.childCount) node.getChild(i)?.let { walk(it, out, lines, depth + 1) }
    }

    /** Takes a real screenshot (JPEG, base64) for screens the element list can't describe well. */
    suspend fun screenshotBase64(): String? = suspendCancellableCoroutine { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    result.hardwareBuffer.close()
                    if (hw == null) { cont.resume(null); return }
                    val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                    val scale = 1024f / maxOf(soft.width, soft.height)
                    val small = Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true)
                    val bytes = ByteArrayOutputStream().also { small.compress(Bitmap.CompressFormat.JPEG, 70, it) }.toByteArray()
                    lastScreenshotScale = scale
                    cont.resume(Base64.encodeToString(bytes, Base64.NO_WRAP))
                } catch (e: Exception) { cont.resume(null) }
            }
            override fun onFailure(errorCode: Int) { cont.resume(null) }
        })
    }

    /** Screenshots are shrunk; this converts coordinates Gemini reads from one back to real pixels. */
    var lastScreenshotScale = 1f
        private set

    // ------------------------------------------------------------------ acting on the screen

    private fun element(id: Int): AccessibilityNodeInfo =
        lastElements.getOrNull(id)?.takeIf { it.refresh() }
            ?: throw IllegalArgumentException("Element [$id] isn't on screen any more. Read the new screen and pick again.")

    suspend fun tap(id: Int): String {
        val node = element(id)
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped [$id]"
            n = n.parent
        }
        val r = Rect().also { node.getBoundsInScreen(it) }
        return if (tapAt(r.centerX(), r.centerY())) "Tapped [$id] by position" else "Could not tap [$id]"
    }

    suspend fun longPress(id: Int): String {
        val node = element(id)
        if (node.isLongClickable && node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return "Long-pressed [$id]"
        val r = Rect().also { node.getBoundsInScreen(it) }
        return if (gesture(path(r.centerX(), r.centerY()), 800)) "Long-pressed [$id] by position" else "Could not long-press [$id]"
    }

    suspend fun tapAt(x: Int, y: Int): Boolean = gesture(path(x, y), 60)

    suspend fun typeText(id: Int, text: String): String {
        val node = element(id)
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed into [$id]"
        else "Could not type into [$id] — it may not be a text box"
    }

    fun pressEnter(): String {
        val focused = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: return "No text box is focused"
        return if (focused.performAction(AccessibilityAction.ACTION_IME_ENTER.id)) "Pressed Enter" else "Enter isn't supported here"
    }

    suspend fun scroll(direction: String, id: Int?): String {
        // Prefer the app's own scrolling, which is reliable; fall back to a finger swipe.
        val target = id?.let { element(it) } ?: lastElements.firstOrNull { it.isScrollable && it.refresh() }
        if (target != null && direction in listOf("down", "up")) {
            val action = if (direction == "down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            if (target.performAction(action)) return "Scrolled $direction"
        }
        val dm = resources.displayMetrics
        val w = dm.widthPixels; val h = dm.heightPixels
        val ok = when (direction) {
            "down" -> swipe(w / 2, h * 3 / 4, w / 2, h / 4)   // finger moves up = content scrolls down
            "up" -> swipe(w / 2, h / 4, w / 2, h * 3 / 4)
            "left" -> swipe(w * 4 / 5, h / 2, w / 5, h / 2)
            "right" -> swipe(w / 5, h / 2, w * 4 / 5, h / 2)
            else -> return "Unknown direction '$direction'"
        }
        return if (ok) "Swiped to scroll $direction" else "Could not scroll"
    }

    suspend fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long = 350): Boolean =
        gesture(Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }, ms)

    fun globalAction(name: String): String {
        val action = when (name) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> return "Unknown button '$name'"
        }
        return if (performGlobalAction(action)) "Pressed $name" else "Could not press $name"
    }

    /** Opens an installed app by its name as shown in the launcher (e.g. "WhatsApp"). */
    fun openApp(name: String): String {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val wanted = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().startsWith(wanted) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(wanted.replace(" ", "")) }
            ?: return "No app called '$name'. Installed apps include: " +
                apps.map { it.loadLabel(pm).toString() }.sorted().take(80).joinToString(", ")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            ?: return "That app can't be opened directly"
        startActivity(intent)
        return "Opened ${match.loadLabel(pm)}"
    }

    // ------------------------------------------------------------------ helpers

    private fun path(x: Int, y: Int) = Path().apply { moveTo(x.toFloat(), y.toFloat()) }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        val ok = suspendCancellableCoroutine { cont ->
            val sent = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!sent && cont.isActive) cont.resume(false)
        }
        delay(100)
        return ok
    }
}
