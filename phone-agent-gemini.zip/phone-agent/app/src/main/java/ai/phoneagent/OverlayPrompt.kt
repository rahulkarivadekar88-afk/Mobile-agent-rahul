package ai.phoneagent

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * Shows a card on top of whatever app is open, so the agent can ask you something
 * (or ask permission) without leaving the screen it is working on.
 */
object OverlayPrompt {

    /** Returns the typed answer, "YES" for an approved confirmation, or null if declined/dismissed. */
    suspend fun ask(ctx: Context, message: String, withTextField: Boolean): String? = withContext(Dispatchers.Main) {
        if (!AndroidSettings.canDrawOverlays(ctx)) return@withContext null
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dp = ctx.resources.displayMetrics.density

        suspendCancellableCoroutine { cont ->
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((20 * dp).toInt(), (20 * dp).toInt(), (20 * dp).toInt(), (12 * dp).toInt())
                background = GradientDrawable().apply { setColor(0xFF1F1E1D.toInt()); cornerRadius = 20 * dp }
                elevation = 12 * dp
            }
            card.addView(TextView(ctx).apply {
                text = "🤖 Phone Agent"
                setTextColor(0xFFD97757.toInt()); textSize = 13f
            })
            card.addView(TextView(ctx).apply {
                text = message
                setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
            })
            val input = if (withTextField) EditText(ctx).apply {
                setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0x99FFFFFF.toInt()); hint = "Type your answer"
            }.also { card.addView(it) } else null

            val row = LinearLayout(ctx).apply { gravity = Gravity.END }
            val no = Button(ctx).apply { text = if (withTextField) "Cancel" else "No" }
            val yes = Button(ctx).apply { text = if (withTextField) "Send" else "Yes, do it" }
            row.addView(no); row.addView(yes)
            card.addView(row)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                // Focusable only when typing is needed, so the keyboard can appear.
                if (withTextField) WindowManager.LayoutParams.FLAG_DIM_BEHIND
                else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.CENTER
                dimAmount = 0.5f
                horizontalMargin = 0.04f
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
            }

            fun done(result: String?) {
                runCatching { wm.removeView(card) }
                if (cont.isActive) cont.resume(result)
            }
            no.setOnClickListener { done(null) }
            yes.setOnClickListener { done(if (input != null) input.text.toString().trim().ifEmpty { null } else "YES") }
            cont.invokeOnCancellation { card.post { runCatching { wm.removeView(card) } } }

            wm.addView(card, params)
            input?.requestFocus()
        }
    }
}
